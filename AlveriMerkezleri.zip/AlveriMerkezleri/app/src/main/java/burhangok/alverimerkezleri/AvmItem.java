package burhangok.alverimerkezleri;

import java.io.Serializable;

public class AvmItem implements Serializable {

    private String avmName;
    private String avmTel;
    private double latValue;

    public AvmItem() {
    }

    public AvmItem(String avmName, String avmTel, double latValue, double longValue) {

        this.avmName = avmName;
        this.avmTel = avmTel;
        this.latValue = latValue;
        this.longValue = longValue;
    }

    public String getAvmName() {
        return avmName;

    }

    public void setAvmName(String avmName) {
        this.avmName = avmName;
    }

    public String getAvmTel() {
        return avmTel;
    }

    public void setAvmTel(String avmTel) {
        this.avmTel = avmTel;
    }

    public double getLatValue() {
        return latValue;
    }

    public void setLatValue(double latValue) {
        this.latValue = latValue;
    }

    public double getLongValue() {
        return longValue;
    }

    public void setLongValue(double longValue) {
        this.longValue = longValue;
    }

    private double longValue;


}
