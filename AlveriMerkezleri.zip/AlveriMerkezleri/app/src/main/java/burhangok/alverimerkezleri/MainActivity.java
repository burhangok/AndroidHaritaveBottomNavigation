package burhangok.alverimerkezleri;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


FragmentTransaction fragmentTransaction;
FragmentManager fragmentManager;

ArrayList<AvmItem> avmItemArrayList = new ArrayList<>();

Bundle bundleObject;

ListeFragment listeFragment;
HaritaFragment haritaFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        avmItemArrayList.add(new AvmItem("Historia Fatih Alışveriş ve Yaşam Merkezi","(0212) 532 02 02",41.0142265,28.9450994));

        avmItemArrayList.add(new AvmItem("İstinye Park","(0212) 345 55 55",41.1100516,29.0324222));


avmItemArrayList.add(new AvmItem("Akyaka Park","(0216) 632 80 80",41.0340847,29.1101869));


        bundleObject = new Bundle();
        listeFragment = new ListeFragment();
        haritaFragment = new HaritaFragment();



        bundleObject.putSerializable("dataList",avmItemArrayList);
        listeFragment.setArguments(bundleObject);
        haritaFragment.setArguments(bundleObject);



        fragmentManager=getSupportFragmentManager();
        fragmentTransaction=fragmentManager.beginTransaction();
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.replace(R.id.fragment_area, listeFragment);
        fragmentTransaction.commit();

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);

        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }


    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_list:
                    fragmentManager=getSupportFragmentManager();
                    fragmentTransaction=fragmentManager.beginTransaction();
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.replace(R.id.fragment_area, listeFragment);
                    fragmentTransaction.commit();
                    return true;
                case R.id.navigation_map:
                    fragmentManager=getSupportFragmentManager();
                    fragmentTransaction=fragmentManager.beginTransaction();
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.replace(R.id.fragment_area, haritaFragment);
                    fragmentTransaction.commit();
                    return true;

            }
            return false;
        }
    };
}
