package burhangok.alverimerkezleri;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class AvmRVAdapter extends RecyclerView.Adapter<AvmRVAdapter.AvmRVHolder> {


    List<AvmItem> avmItems;
    LayoutInflater layoutInflater;

    public AvmRVAdapter(Context context,List<AvmItem> avmItems) {
        this.avmItems = avmItems;
        this.layoutInflater= (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @NonNull
    @Override
    public AvmRVHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View rowView = layoutInflater.inflate(R.layout.row_layout,null);

        AvmRVHolder avmRVHolder = new AvmRVHolder(rowView);


        return avmRVHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull AvmRVHolder avmRVHolder, int i) {

        AvmItem avmItem = avmItems.get(i);

        avmRVHolder.nameTV.setText(avmItem.getAvmName());
        avmRVHolder.phoneTV.setText(avmItem.getAvmTel());



    }

    @Override
    public int getItemCount() {
        return avmItems.size();
    }


    class AvmRVHolder extends RecyclerView.ViewHolder {

        TextView nameTV,phoneTV;

        public AvmRVHolder(@NonNull View itemView) {
            super(itemView);

            nameTV=itemView.findViewById(R.id.name);
            phoneTV=itemView.findViewById(R.id.telephone);

        }
    }  {

    }
}
