package burhangok.alverimerkezleri;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class HaritaFragment extends Fragment implements OnMapReadyCallback {


    public HaritaFragment() {
        // Required empty public constructor
    }

    View fragmentView;
    MapView  mapView;
    GoogleMap map;

    List<AvmItem> avmItemList;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        fragmentView = inflater.inflate(R.layout.fragment_harita,null);

        avmItemList= (List<AvmItem>) getArguments().getSerializable("dataList");

        mapView= fragmentView.findViewById(R.id.mapView);

        mapView.onCreate(savedInstanceState);

        mapView.getMapAsync(this);

        return fragmentView;

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

        map=googleMap;

        LatLng latLng =null;

        for (int i =0; i<avmItemList.size(); i++) {


            latLng = new LatLng(avmItemList.get(i).getLatValue(),avmItemList.get(i).getLongValue());
            map.addMarker(new MarkerOptions().position(latLng).title(avmItemList.get(i).getAvmName()));
            map.moveCamera(CameraUpdateFactory.newLatLng(latLng));

        }

        CameraPosition cameraPosition = CameraPosition.builder()
                .target(latLng)
                .zoom(10)
                .bearing(0)
                .tilt(45)
                .build();

        map.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));



    }

    @Override
    public void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        mapView.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        mapView.onSaveInstanceState(outState);
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }
}
