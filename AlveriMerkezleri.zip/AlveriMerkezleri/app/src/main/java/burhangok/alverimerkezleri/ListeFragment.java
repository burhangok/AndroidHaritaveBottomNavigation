package burhangok.alverimerkezleri;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class ListeFragment extends Fragment {

    List<AvmItem> avmItemList;
    View fragmentView;

    RecyclerView dataRV;

    LinearLayoutManager linearLayoutManager;
    AvmRVAdapter avmRVAdapter;

    public ListeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        fragmentView=inflater.inflate(R.layout.fragment_liste,null);


        avmItemList= (List<AvmItem>) getArguments().getSerializable("dataList");


        dataRV = fragmentView.findViewById(R.id.avmList);

        linearLayoutManager = new LinearLayoutManager(fragmentView.getContext());

        avmRVAdapter = new AvmRVAdapter(fragmentView.getContext(),avmItemList);

        dataRV.setLayoutManager(linearLayoutManager);
        dataRV.setAdapter(avmRVAdapter);


        return fragmentView;


    }

}
